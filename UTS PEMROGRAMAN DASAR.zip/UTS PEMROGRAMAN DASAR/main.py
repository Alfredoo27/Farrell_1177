import argparse
import logging
import os
import sys
from datetime import datetime

from tools import __version__
from tools.berkas import baca_data, tulis_csv, tulis_json
from tools.errors import DataTidakValidError, FormatFileError
from tools.olah import (
    cari_judul, daftar_mata_kuliah, filter_tugas, hapus_duplikat,
    kunci_tugas, rekap_per_matkul, tugas_terlambat,
)
from tools.tampilan import format_tabel
from tools.validasi import (
    STATUS_VALID, URUTAN_STATUS, bersihkan_data, normalisasi_record, tanggal_hari_ini,
)

logger = logging.getLogger("arsip_tugas")

KOLOM_TUGAS = ("judul", "mata_kuliah", "deadline", "status", "nilai")
KOLOM_REKAP = ("mata_kuliah", "total", "belum", "proses", "selesai", "persen_selesai", "rata_nilai")
KOLOM_TERLAMBAT = ("judul", "mata_kuliah", "deadline", "status")

MENU = """
===== ARSIP TUGAS MAHASISWA =====
1. Lihat semua tugas
2. Cari tugas (judul)
3. Filter tugas (status / mata kuliah)
4. Rekap per mata kuliah
5. Tugas terlambat
6. Tambah tugas
7. Simpan hasil ke folder output
0. Keluar"""

# Kode keluar program
OK, GAGAL_FILE, GAGAL_FORMAT, DIBATALKAN = 0, 1, 2, 130


def parse_tanggal_acuan(teks):
    """Validator argparse untuk --tanggal. Return datetime.date."""
    try:
        return datetime.strptime(teks, "%Y-%m-%d").date()
    except ValueError:
        raise argparse.ArgumentTypeError(f"'{teks}' bukan tanggal YYYY-MM-DD") from None


def parse_argumen(argv):
    """Baca argumen command line. Parameter: argv (list str/None). Return: argparse.Namespace."""
    parser = argparse.ArgumentParser(description="Pengolah arsip tugas mahasiswa (CSV/JSON).")
    parser.add_argument("--input", "-i", default=os.path.join("data", "tugas_input.csv"),
                        help="file input .csv atau .json (default: data/tugas_input.csv)")
    parser.add_argument("--output", "-o", default="output",
                        help="folder hasil (default: output)")
    parser.add_argument("--tanggal", type=parse_tanggal_acuan, default=None,
                        help="tanggal acuan cek keterlambatan, YYYY-MM-DD (default: hari ini)")
    parser.add_argument("--batch", action="store_true",
                        help="proses dan simpan hasil tanpa menu interaktif")
    parser.add_argument("--debug", action="store_true",
                        help="tulis log level DEBUG (untuk pengembangan)")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    return parser.parse_args(argv)


def siapkan_logging(folder, debug=False):
    """Arahkan log ke <folder>/arsip.log. Return: path file log."""
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, "arsip.log")
    handler = logging.FileHandler(path, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(name)s - %(message)s"))
    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(logging.DEBUG if debug else logging.INFO)
    return path


#proses data

def muat_data(path):
    """Baca file, validasi tiap baris, lalu hapus duplikat.

    Parameter: path (str).
    Return: dict {"tugas": list valid & unik, "ditolak": list pesan,
                  "duplikat": int, "jumlah_baris": int}.
    Raise: FileNotFoundError, FormatFileError, OSError.
    """
    mentah = baca_data(path)
    valid, ditolak = bersihkan_data(mentah)
    unik, duplikat = hapus_duplikat(valid)
    for pesan in ditolak:
        logger.warning("Data ditolak - %s", pesan)
    if duplikat:
        logger.warning("%d data duplikat dibuang.", duplikat)
    return {"tugas": unik, "ditolak": ditolak, "duplikat": duplikat, "jumlah_baris": len(mentah)}


def ringkasan_muat(info):
    """Buat teks ringkasan hasil muat data. Parameter: info (dict dari muat_data). Return: str."""
    baris = [
        f"Baris dibaca : {info['jumlah_baris']}",
        f"Data valid   : {len(info['tugas'])}",
        f"Ditolak      : {len(info['ditolak'])}",
        f"Duplikat     : {info['duplikat']}",
    ]
    baris += [f"  - {pesan}" for pesan in info["ditolak"]]
    return "\n".join(baris)


def buat_laporan(info, sumber, tanggal_acuan):
    """Susun laporan teks lengkap. Return: str."""
    tugas = info["tugas"]
    terlambat = tugas_terlambat(tugas, tanggal_acuan)
    bagian = [
        "LAPORAN ARSIP TUGAS MAHASISWA",
        f"Sumber data   : {sumber}",
        f"Tanggal acuan : {tanggal_acuan.isoformat()}",
        "",
        "[Ringkasan validasi]",
        ringkasan_muat(info),
        "",
        "[Rekap per mata kuliah]",
        format_tabel(rekap_per_matkul(tugas), KOLOM_REKAP),
        "",
        f"[Tugas terlambat: {len(terlambat)}]",
        format_tabel(terlambat, KOLOM_TERLAMBAT),
    ]
    return "\n".join(bagian) + "\n"


def simpan_hasil(info, sumber, folder, tanggal_acuan):
    """Tulis semua file output.

    Parameter: info (dict), sumber (str), folder (str), tanggal_acuan (date).
    Return: list path file yang dibuat. Raise: OSError.
    """
    tugas = info["tugas"]
    data_json = {
        "sumber": sumber,
        "tanggal_acuan": tanggal_acuan.isoformat(),
        "jumlah": len(tugas),
        "tugas": tugas,
    }
    path_laporan = os.path.join(folder, "laporan.txt")
    with open(path_laporan, "w", encoding="utf-8") as f:
        f.write(buat_laporan(info, sumber, tanggal_acuan))
    return [
        tulis_json(os.path.join(folder, "tugas_bersih.json"), data_json),
        tulis_csv(os.path.join(folder, "rekap_matkul.csv"), rekap_per_matkul(tugas), KOLOM_REKAP),
        tulis_csv(os.path.join(folder, "tugas_terlambat.csv"),
                  tugas_terlambat(tugas, tanggal_acuan), KOLOM_TERLAMBAT),
        path_laporan,
    ]


#menu interaktif

def minta_status(prompt, boleh_kosong=True):
    """Minta input status. Return: status (str), None jika dikosongkan, atau '' jika tidak valid."""
    teks = input(prompt).strip().lower()
    if not teks:
        return None if boleh_kosong else ""
    if teks not in STATUS_VALID:
        logger.warning("Status filter tidak valid: %r", teks)
        print(f"Status harus salah satu dari: {', '.join(URUTAN_STATUS)}.")
        return ""
    return teks


def menu_cari(tugas):
    """Menu cari judul. Return: list hasil."""
    kata = input("Kata kunci judul: ")
    if not kata.strip():
        logger.warning("Kata kunci pencarian kosong.")
        print("Kata kunci tidak boleh kosong.")
        return []
    hasil = cari_judul(tugas, kata)
    print(f"Ditemukan {len(hasil)} tugas.")
    print(format_tabel(hasil, KOLOM_TUGAS))
    return hasil


def menu_filter(tugas):
    """Menu filter status/mata kuliah. Return: list hasil."""
    status = minta_status(f"Status ({'/'.join(URUTAN_STATUS)}, kosongkan = semua): ")
    if status == "":
        return []
    matkul_tersedia = daftar_mata_kuliah(tugas)
    print("Mata kuliah tersedia: " + (", ".join(matkul_tersedia) or "-"))
    matkul = input("Mata kuliah (kosongkan = semua): ").strip() or None
    if matkul and matkul.lower() not in {m.lower() for m in matkul_tersedia}:
        logger.warning("Mata kuliah tidak ditemukan: %r", matkul)
        print(f"Mata kuliah '{matkul}' tidak ada di data.")
        return []
    hasil = filter_tugas(tugas, status=status, mata_kuliah=matkul)
    print(format_tabel(hasil, KOLOM_TUGAS))
    return hasil


def menu_tambah(tugas):
    """Menu tambah tugas baru ke list. Return: dict tugas baru, atau None jika gagal."""
    baris = {
        "judul": input("Judul: "),
        "mata_kuliah": input("Mata kuliah: "),
        "deadline": input("Deadline (YYYY-MM-DD): "),
        "status": input(f"Status ({'/'.join(URUTAN_STATUS)}): "),
    }
    baris["nilai"] = input("Nilai 0-100 (kosongkan jika belum ada): ") \
        if baris["status"].strip().lower() == "selesai" else ""
    try:
        baru = normalisasi_record(baris)
    except DataTidakValidError as e:
        logger.warning("Input tugas ditolak: %s", e)
        print(f"Gagal: {e}.")
        return None
    if kunci_tugas(baru) in {kunci_tugas(t) for t in tugas}:
        logger.warning("Input tugas duplikat: %s", baru["judul"])
        print("Gagal: tugas dengan judul dan mata kuliah yang sama sudah ada.")
        return None
    tugas.append(baru)
    logger.info("Tugas ditambahkan: %s (%s)", baru["judul"], baru["mata_kuliah"])
    print("Tugas ditambahkan. Pilih menu 7 untuk menyimpan.")
    return baru


def jalankan_menu(info, args, tanggal_acuan):
    """Loop menu interaktif. Return: kode keluar (int)."""
    tugas = info["tugas"]
    while True:
        print(MENU)
        pilihan = input("Pilihan: ").strip()
        logger.debug("Pilihan menu: %r", pilihan)

        if pilihan == "1":
            print(format_tabel(tugas, KOLOM_TUGAS))
        elif pilihan == "2":
            menu_cari(tugas)
        elif pilihan == "3":
            menu_filter(tugas)
        elif pilihan == "4":
            print(format_tabel(rekap_per_matkul(tugas), KOLOM_REKAP))
        elif pilihan == "5":
            terlambat = tugas_terlambat(tugas, tanggal_acuan)
            print(f"Tanggal acuan {tanggal_acuan.isoformat()}: {len(terlambat)} tugas terlambat.")
            print(format_tabel(terlambat, KOLOM_TERLAMBAT))
        elif pilihan == "6":
            menu_tambah(tugas)
        elif pilihan == "7":
            try:
                for path in simpan_hasil(info, args.input, args.output, tanggal_acuan):
                    print(f"Tersimpan: {path}")
            except OSError as e:
                logger.error("Gagal menyimpan output: %s", e)
                print(f"Gagal menyimpan: {e}")
        elif pilihan == "0":
            print("Selesai.")
            return OK
        elif pilihan == "":
            logger.warning("Pilihan menu kosong.")
            print("Pilihan tidak boleh kosong.")
        else:
            logger.warning("Pilihan menu tidak valid: %r", pilihan)
            print("Pilihan tidak valid. Pilih 0-7.")


# ---------------------------------------------------------------- program utama

def main(argv=None):
    """Titik masuk program. Parameter: argv (list/None). Return: kode keluar (int)."""
    args = parse_argumen(argv)
    try:
        path_log = siapkan_logging(args.output, args.debug)
    except OSError as e:
        print(f"Tidak bisa membuat folder output '{args.output}': {e}", file=sys.stderr)
        return GAGAL_FILE
    tanggal_acuan = args.tanggal or tanggal_hari_ini()
    logger.info("Aplikasi mulai. input=%s, tanggal_acuan=%s", args.input, tanggal_acuan)

    try:
        info = muat_data(args.input)
    except FileNotFoundError:
        logger.error("File input tidak ditemukan: %s", args.input)
        print(f"Error: file '{args.input}' tidak ditemukan. Cek path atau gunakan --input.")
        return GAGAL_FILE
    except FormatFileError as e:
        logger.error("Format file salah: %s", e)
        print(f"Error: {e}")
        return GAGAL_FORMAT
    except OSError as e:  # mis. PermissionError, path berupa folder
        logger.error("Gagal membaca %s: %s", args.input, e)
        print(f"Error: tidak bisa membaca '{args.input}': {e}")
        return GAGAL_FILE

    print(f"Memuat {args.input}")
    print(ringkasan_muat(info))
    if not info["tugas"]:
        print("Peringatan: tidak ada data tugas yang valid.")

    try:
        if args.batch:
            for path in simpan_hasil(info, args.input, args.output, tanggal_acuan):
                print(f"Tersimpan: {path}")
            kode = OK
        else:
            kode = jalankan_menu(info, args, tanggal_acuan)
    except (KeyboardInterrupt, EOFError):
        logger.info("Dihentikan pengguna.")
        print("\nDihentikan.")
        return DIBATALKAN
    except OSError as e:
        logger.error("Gagal menulis output: %s", e)
        print(f"Error: gagal menulis output: {e}")
        return GAGAL_FILE

    logger.info("Aplikasi selesai (kode %d). Log: %s", kode, path_log)
    return kode


if __name__ == "__main__":
    sys.exit(main())
