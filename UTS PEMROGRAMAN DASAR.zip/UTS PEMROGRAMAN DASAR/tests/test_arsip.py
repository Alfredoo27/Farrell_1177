"""Pengujian otomatis package arsip. Jalankan: python -m unittest discover -s tests -v"""

import os
import sys
import tempfile
import unittest
from datetime import date

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tools.berkas import baca_csv, baca_data, tulis_json  # noqa: E402
from tools.errors import DataTidakValidError, FormatFileError  # noqa: E402
from tools.olah import (  # noqa: E402
    cari_judul, filter_tugas, hapus_duplikat, rekap_per_matkul, tugas_terlambat,
)
from tools.validasi import bersihkan_data, normalisasi_record  # noqa: E402


def tugas(judul, matkul="Pemrograman Dasar", deadline="2026-11-01", status="belum", nilai=None):
    return {"judul": judul, "mata_kuliah": matkul, "deadline": deadline, "status": status, "nilai": nilai}


class TestValidasi(unittest.TestCase):
    def test_data_normal_dirapikan(self):
        hasil = normalisasi_record({"judul": "  Tugas   1 ", "mata_kuliah": "PD", "deadline": "2026-11-01",
                                    "status": "SELESAI", "nilai": "85,5"})
        self.assertEqual(hasil["judul"], "Tugas 1")
        self.assertEqual(hasil["status"], "selesai")
        self.assertEqual(hasil["nilai"], 85.5)

    def test_tanggal_tidak_ada(self):
        with self.assertRaises(DataTidakValidError):
            normalisasi_record(tugas("A", deadline="2026-02-30"))

    def test_status_salah(self):
        with self.assertRaises(DataTidakValidError):
            normalisasi_record(tugas("A", status="sudah"))

    def test_nilai_di_luar_rentang(self):
        with self.assertRaises(DataTidakValidError):
            normalisasi_record(tugas("A", status="selesai", nilai="120"))

    def test_nilai_nol_tetap_valid(self):
        self.assertEqual(normalisasi_record(tugas("A", status="selesai", nilai=0))["nilai"], 0.0)

    def test_baris_salah_tidak_menghentikan_proses(self):
        valid, galat = bersihkan_data([tugas("A"), tugas(""), "bukan dict"])
        self.assertEqual(len(valid), 1)
        self.assertEqual(len(galat), 2)


class TestOlah(unittest.TestCase):
    def test_hapus_duplikat_abaikan_huruf_besar(self):
        unik, dibuang = hapus_duplikat([tugas("Lap 1"), tugas("lap 1"), tugas("Lap 2")])
        self.assertEqual([t["judul"] for t in unik], ["Lap 1", "Lap 2"])
        self.assertEqual(dibuang, 1)

    def test_cari_kata_kunci_kosong(self):
        self.assertEqual(cari_judul([tugas("A")], "   "), [])

    def test_filter_status_dan_matkul(self):
        data = [tugas("A", status="proses"), tugas("B", matkul="Fisika", status="proses")]
        self.assertEqual(len(filter_tugas(data, status="PROSES", mata_kuliah="fisika")), 1)

    def test_rekap_data_kosong_tanpa_error(self):
        self.assertEqual(rekap_per_matkul([]), [])

    def test_rekap_rata_nilai(self):
        data = [tugas("A", status="selesai", nilai=80.0), tugas("B", status="selesai", nilai=90.0), tugas("C")]
        rekap = rekap_per_matkul(data)[0]
        self.assertEqual(rekap["rata_nilai"], 85.0)
        self.assertEqual(rekap["persen_selesai"], 66.7)

    def test_terlambat_batas_tanggal(self):
        data = [tugas("Lewat", deadline="2026-11-16"), tugas("Hari ini", deadline="2026-11-17"),
                tugas("Selesai", deadline="2026-11-01", status="selesai")]
        hasil = tugas_terlambat(data, date(2026, 11, 17))
        self.assertEqual([t["judul"] for t in hasil], ["Lewat"])


class TestBerkas(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()

    def tearDown(self):
        self.tmp.cleanup()

    def path(self, nama):
        return os.path.join(self.tmp.name, nama)

    def test_csv_dengan_bom_excel(self):
        p = self.path("bom.csv")
        with open(p, "w", encoding="utf-8-sig") as f:
            f.write("judul,mata_kuliah,deadline,status,nilai\nA,PD,2026-11-01,belum,\n")
        self.assertEqual(baca_csv(p)[0]["judul"], "A")

    def test_csv_kolom_kurang(self):
        p = self.path("salah.csv")
        with open(p, "w", encoding="utf-8") as f:
            f.write("nama,status\nA,belum\n")
        with self.assertRaises(FormatFileError):
            baca_csv(p)

    def test_json_rusak(self):
        p = self.path("rusak.json")
        with open(p, "w", encoding="utf-8") as f:
            f.write('[{"judul": "A",]')
        with self.assertRaises(FormatFileError):
            baca_data(p)

    def test_file_tidak_ada(self):
        with self.assertRaises(FileNotFoundError):
            baca_data(self.path("tidak_ada.csv"))

    def test_json_tulis_lalu_baca_kembali(self):
        p = self.path("hasil.json")
        tulis_json(p, {"tugas": [tugas("A")]})
        self.assertEqual(baca_data(p)[0]["judul"], "A")


if __name__ == "__main__":
    unittest.main()
