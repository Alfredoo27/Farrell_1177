# Arsip Tugas Mahasiswa

UTS Pemrograman Dasar (TK091) – S1 Teknik Komputer, Universitas AMIKOM Yogyakarta

| Nama | _Farrell Putra Wijaya_ |
| NIM | _25.83.1177_ |
| Kelas | _TK01_ |


1. Struktur program

```
uts_arsip_tugas/
├── main.py                  # entry point: argumen CLI, menu, alur program
├── tools/                   # package buatan sendiri
│   ├── __init__.py          # penanda package + versi
│   ├── errors.py            # exception khusus: FormatFileError, DataTidakValidError
│   ├── validasi.py          # aturan validasi & normalisasi satu data tugas
│   ├── berkas.py            # baca/tulis CSV dan JSON
│   ├── olah.py              # hapus duplikat, cari, filter, kelompok, rekap, terlambat
│   └── tampilan.py          # mengubah list of dict menjadi tabel teks
├── data/                    # contoh file input
│   ├── tugas_input.csv      # data normal (15 tugas)
│   ├── tugas_input.json     # data normal versi JSON
│   ├── tugas_edge_case.csv  # duplikat, kolom kosong, tanggal/status/nilai salah
│   ├── tugas_kosong.csv     # hanya header (edge case data kosong)
│   ├── tugas_kolom_salah.csv# nama kolom tidak sesuai (error format)
│   ├── tugas_rusak.json     # JSON rusak (error format)
│   └── tugas_excel_bom.csv  # CSV ber-BOM dari Excel (skenario debugging)
├── output/                  # contoh hasil yang sudah dijalankan
│   ├── tugas_bersih.json, rekap_matkul.csv, tugas_terlambat.csv, laporan.txt, arsip.log
│   ├── edge_case/           # hasil dari tugas_edge_case.csv
│   ├── kosong/              # hasil dari tugas_kosong.csv
│   ├── contoh_output_terminal.txt  # rekaman output terminal (normal, edge case, error)
│   └── contoh_sesi_menu.txt        # rekaman sesi menu interaktif
├── tests/test_arsip.py      # 17 unit test (unittest)
└── README.md
```
2. Package buatan sendiri

| Package | Keterangan |
|---|---|
| `tools` | berisi seluruh logika aplikasi: validasi, baca/tulis file, pengolahan data, dan tampilan tabel |

3. Alur dependensi antar-module

```
main.py
  ├── arsip.berkas    ──► arsip.errors, arsip.validasi (konstanta KOLOM_WAJIB)
  ├── arsip.validasi  ──► arsip.errors
  ├── arsip.olah      ──► arsip.validasi (konstanta URUTAN_STATUS)
  ├── arsip.tampilan  (tidak bergantung module lain)
  └── arsip.errors    (tidak bergantung module lain)
```

Dependensi hanya mengalir satu arah (tidak ada import melingkar). `main.py` adalah satu-satunya
module yang berinteraksi dengan pengguna (`input`/`print`); module di dalam package hanya
menerima parameter dan mengembalikan nilai, sehingga mudah diuji.

Urutan pemanggilan saat program berjalan:

```
main()
 ├─ parse_argumen()            -> argumen --input, --output, --tanggal, --batch, --debug
 ├─ siapkan_logging()          -> output/arsip.log
 ├─ muat_data(path)
 │    ├─ berkas.baca_data()    -> baca_csv() / baca_json()      : list of dict mentah
 │    ├─ validasi.bersihkan_data() -> normalisasi_record() tiap baris : (valid, ditolak)
 │    └─ olah.hapus_duplikat() -> (unik, jumlah_duplikat)
 ├─ mode --batch : simpan_hasil() -> olah.rekap_per_matkul(), olah.tugas_terlambat(),
 │                                   berkas.tulis_json(), berkas.tulis_csv()
 └─ mode menu    : jalankan_menu() -> olah.cari_judul(), olah.filter_tugas(), ...,
                                      tampilan.format_tabel()
```

4. Cara Mengaktifkan

Buka terminal di folder proyek (folder yang berisi `main.py`). Di Windows gunakan `python`.

```bash
# Mode menu interaktif dengan data default (data/tugas_input.csv)
python main.py

Setelah itu akan muncul Menu interaktif diterminal output :

Menu interaktif:

```
1. Lihat semua tugas
2. Cari tugas (judul)
3. Filter tugas (status / mata kuliah)
4. Rekap per mata kuliah
5. Tugas terlambat
6. Tambah tugas
7. Simpan hasil ke folder output
0. Keluar


5. Penjelasan Menu Interaktif :
1. Lihat semua tugas

Menampilkan seluruh tugas yang valid dalam bentuk tabel, berisi kode MK, nama mata kuliah,
jenis (teori/praktikum), judul, deadline, status, dan nilai. Tugas yang belum dinilai
ditampilkan dengan tanda `-`. Tugas yang ditambahkan lewat menu 6 juga ikut tampil di sini.

2. Cari tugas (judul)

Mencari tugas berdasarkan kata kunci pada judul. Pencarian tidak membedakan huruf besar
dan kecil, dan cukup memasukkan sebagian judul.

Contoh :

Pilihan: 2
Kata kunci judul: subnetting
Ditemukan 1 tugas.


Jika kata kunci dikosongkan, program menampilkan pesan `Kata kunci tidak boleh kosong.`

3. Filter tugas (status / kode MK / jenis)

Menyaring tugas berdasarkan tiga kriteria yang ditanyakan berurutan:

1. **Status:** `belum`, `proses`, atau `selesai`
2. **Kode MK:** misalnya `TK091` (daftar kode yang tersedia ditampilkan otomatis)
3. **Jenis:** `teori` atau `praktikum`

Kriteria yang dikosongkan (langsung Enter) berarti tidak disaring. Contoh: untuk melihat
semua tugas praktikum Pemrograman Dasar, kosongkan status, isi kode `TK091`, dan isi jenis
`praktikum`. Jika isian tidak sesuai pilihan, misalnya status `sudah`, program menampilkan
pilihan yang benar lalu kembali ke menu.

4. Rekap per mata kuliah

Menampilkan rekap untuk semua 11 mata kuliah di katalog:

| Kolom | Arti |
|---|---|
| `total` | jumlah tugas di mata kuliah tersebut |
| `belum`, `proses`, `selesai` | jumlah tugas untuk setiap status |
| `persen_selesai` | persentase tugas yang sudah selesai |
| `rata_nilai` | rata-rata nilai tugas yang sudah dinilai |

Mata kuliah yang belum punya tugas tetap ditampilkan dengan total 0 dan rata-rata `-`.

5. Tugas terlambat

Menampilkan tugas yang **belum selesai** dan deadline-nya **sudah lewat** dari tanggal acuan,
diurutkan dari deadline paling lama. Tanggal acuan adalah hari ini, atau tanggal yang
diberikan lewat `--tanggal`.


Pilihan: 5
Tanggal acuan 2026-11-17: 3 tugas terlambat.


Tugas yang deadline-nya sama dengan tanggal acuan belum dihitung terlambat.

6. Tambah tugas

Menambahkan tugas baru. Program menampilkan daftar mata kuliah, lalu menanyakan:

| Isian | Contoh | Aturan |
|---|---|---|
| Kode MK | `TK082` | harus ada di daftar mata kuliah |
| Jenis | `teori` | `teori` atau `praktikum`, dan pasangannya harus cocok dengan katalog |
| Judul | `Kuis Sensor dan Aktuator` | tidak boleh kosong, maksimal 100 karakter |
| Deadline | `2026-11-20` | format `YYYY-MM-DD` dan tanggalnya harus ada |
| Status | `belum` | `belum`, `proses`, atau `selesai` |
| Nilai | `90` | hanya ditanyakan jika status `selesai`; angka 0–100, boleh dikosongkan |

Jika berhasil, muncul pesan `Tugas ditambahkan. Pilih menu 7 untuk menyimpan.`
Tugas ditolak jika ada isian yang salah (misalnya tanggal `2026-11-31` atau `TK092 praktikum`
yang tidak ada di katalog), atau jika tugas dengan judul, kode MK, dan jenis yang sama
sudah ada.

> **Penting:** tugas baru hanya tersimpan di memori. Pilih menu 7 sebelum keluar agar
> tidak hilang.

7. Simpan hasil ke folder output

Menyimpan data saat ini, termasuk tugas yang baru ditambahkan, ke folder `output/`:


Tersimpan: output/tugas_bersih.json
Tersimpan: output/rekap_matkul.csv
Tersimpan: output/tugas_terlambat.csv
Tersimpan: output/laporan.txt


File input asli di folder `data/` tidak diubah. Untuk melanjutkan dengan data yang sudah
ditambah, jalankan:

bash
python main.py -i output/tugas_bersih.json


8. Keluar

Menutup program dengan pesan `Selesai.` Tugas yang ditambahkan tetapi belum disimpan
lewat menu 7 akan hilang.
