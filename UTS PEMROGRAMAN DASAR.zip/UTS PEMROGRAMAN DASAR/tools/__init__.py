"""
Package `arsip` - pengolahan arsip tugas mahasiswa.

Isi package:
- errors    : kelas exception khusus aplikasi
- validasi  : aturan validasi dan normalisasi satu data tugas
- berkas    : baca/tulis file CSV dan JSON
- olah      : pencarian, filter, pengelompokan, rekap, hapus duplikat
- tampilan  : mengubah data menjadi teks tabel untuk ditampilkan di terminal
"""

__version__ = "1.0.0"
