from datetime import date, datetime

from .errors import DataTidakValidError

KOLOM_WAJIB = ("judul", "mata_kuliah", "deadline", "status")
KOLOM_SEMUA = KOLOM_WAJIB + ("nilai",)
URUTAN_STATUS = ("belum", "proses", "selesai")
STATUS_VALID = set(URUTAN_STATUS)  # set: cek keanggotaan cepat dan tanpa duplikat
MAKS_JUDUL = 100
FORMAT_TANGGAL = "%Y-%m-%d"


def ke_teks(nilai):
    return "" if nilai is None else str(nilai).strip()


def parse_tanggal(teks):
    try:
        return datetime.strptime(teks, FORMAT_TANGGAL).date()
    except (ValueError, TypeError):
        raise DataTidakValidError(
            f"deadline '{teks}' bukan tanggal valid (format YYYY-MM-DD)"
        ) from None


def parse_nilai(teks):
    teks = ke_teks(teks)
    if teks == "":
        return None
    try:
        nilai = float(teks.replace(",", "."))  # terima desimal koma, mis. 85,5
    except ValueError:
        raise DataTidakValidError(f"nilai '{teks}' bukan angka") from None
    if not 0 <= nilai <= 100:
        raise DataTidakValidError(f"nilai {nilai:g} di luar rentang 0-100")
    return nilai


def normalisasi_record(baris):
    if not isinstance(baris, dict):
        raise DataTidakValidError("data bukan objek/dictionary")

    bersih = {kolom: ke_teks(baris.get(kolom)) for kolom in KOLOM_SEMUA}  # dict comprehension
    kosong = [kolom for kolom in KOLOM_WAJIB if not bersih[kolom]]       # list comprehension
    if kosong:
        raise DataTidakValidError(f"kolom wajib kosong: {', '.join(kosong)}")

    if len(bersih["judul"]) > MAKS_JUDUL:
        raise DataTidakValidError(f"judul lebih dari {MAKS_JUDUL} karakter")

    status = bersih["status"].lower()
    if status not in STATUS_VALID:
        raise DataTidakValidError(
            f"status '{bersih['status']}' tidak dikenal (pilihan: {', '.join(URUTAN_STATUS)})"
        )

    deadline = parse_tanggal(bersih["deadline"])
    nilai = parse_nilai(bersih["nilai"])
    if nilai is not None and status != "selesai":
        raise DataTidakValidError("nilai hanya boleh diisi untuk tugas berstatus selesai")

    return {
        "judul": " ".join(bersih["judul"].split()),  # rapikan spasi ganda
        "mata_kuliah": " ".join(bersih["mata_kuliah"].split()),
        "deadline": deadline.isoformat(),
        "status": status,
        "nilai": nilai,
    }


def bersihkan_data(daftar_baris):
    valid, galat = [], []
    for nomor, baris in enumerate(daftar_baris, start=1):
        try:
            valid.append(normalisasi_record(baris))
        except DataTidakValidError as e:
            galat.append(f"Data ke-{nomor}: {e}")
    return valid, galat


def tanggal_hari_ini():
    return date.today()
