def format_sel(nilai):
    if nilai is None:
        return "-"
    if isinstance(nilai, float):
        return f"{nilai:g}"
    return str(nilai)


def format_tabel(daftar_baris, kolom, nomor=True):
    if not daftar_baris:
        return "(tidak ada data)"
    kepala = (["No"] if nomor else []) + list(kolom)
    isi = [
        ([str(i)] if nomor else []) + [format_sel(b.get(k)) for k in kolom]
        for i, b in enumerate(daftar_baris, start=1)
    ]
    semua = [kepala] + isi
    lebar = [max(len(baris[i]) for baris in semua) for i in range(len(kepala))]
    garis = "-+-".join("-" * w for w in lebar)
    teks = [" | ".join(sel.ljust(w) for sel, w in zip(baris, lebar)).rstrip() for baris in semua]
    return "\n".join([teks[0], garis] + teks[1:])
