from .validasi import URUTAN_STATUS


def kunci_tugas(tugas):
    return (tugas["judul"].lower(), tugas["mata_kuliah"].lower())


def hapus_duplikat(daftar_tugas):
    sudah_ada = set()  # set: cek "sudah pernah muncul?" dengan cepat
    unik = []
    for tugas in daftar_tugas:
        kunci = kunci_tugas(tugas)
        if kunci in sudah_ada:
            continue
        sudah_ada.add(kunci)
        unik.append(tugas)
    return unik, len(daftar_tugas) - len(unik)


def cari_judul(daftar_tugas, kata_kunci):
    kata_kunci = kata_kunci.strip().lower()
    if not kata_kunci:
        return []
    return [t for t in daftar_tugas if kata_kunci in t["judul"].lower()]


def filter_tugas(daftar_tugas, status=None, mata_kuliah=None):
    return [
        t for t in daftar_tugas
        if (status is None or t["status"] == status.lower())
        and (mata_kuliah is None or t["mata_kuliah"].lower() == mata_kuliah.lower())
    ]


def daftar_mata_kuliah(daftar_tugas):
    return sorted({t["mata_kuliah"] for t in daftar_tugas})  # set comprehension


def kelompokkan_per_matkul(daftar_tugas):
    kelompok = {}
    for tugas in daftar_tugas:
        kelompok.setdefault(tugas["mata_kuliah"], []).append(tugas)
    return kelompok


def rekap_per_matkul(daftar_tugas):
    hasil = []
    kelompok = kelompokkan_per_matkul(daftar_tugas)
    for matkul in sorted(kelompok):
        tugas_matkul = kelompok[matkul]
        total = len(tugas_matkul)  # selalu > 0 karena kelompok hanya dibuat jika ada tugas
        per_status = {s: sum(1 for t in tugas_matkul if t["status"] == s) for s in URUTAN_STATUS}
        nilai = [t["nilai"] for t in tugas_matkul if t["nilai"] is not None]
        hasil.append({
            "mata_kuliah": matkul,
            "total": total,
            **per_status,
            "persen_selesai": round(per_status["selesai"] / total * 100, 1),
            "rata_nilai": round(sum(nilai) / len(nilai), 2) if nilai else None,
        })
    return hasil


def tugas_terlambat(daftar_tugas, tanggal_acuan):
    acuan = tanggal_acuan.isoformat()  # format ISO bisa dibandingkan sebagai string
    terlambat = [t for t in daftar_tugas if t["status"] != "selesai" and t["deadline"] < acuan]
    return sorted(terlambat, key=lambda t: t["deadline"])
