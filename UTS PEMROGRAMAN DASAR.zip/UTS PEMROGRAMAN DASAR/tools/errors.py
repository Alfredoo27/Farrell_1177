"""Exception khusus aplikasi arsip tugas."""


class ArsipError(Exception):
    """Kelas dasar semua error aplikasi."""


class FormatFileError(ArsipError):
    """File ditemukan, tetapi isinya tidak sesuai format yang diharapkan."""


class DataTidakValidError(ArsipError):
    """Satu data tugas tidak lolos aturan validasi."""
