import csv
import json
import logging
import os

from .errors import FormatFileError
from .validasi import KOLOM_WAJIB

logger = logging.getLogger(__name__)


def baca_csv(path):
    """Baca file CSV menjadi list of dict dengan nama kolom huruf kecil.

    Parameter: path (str).
    Return: list of dict (kosong jika file kosong atau hanya berisi header).
    Raise: FileNotFoundError, FormatFileError (kolom wajib tidak ada / encoding salah).
    """
    try:
        # utf-8-sig membuang BOM dari CSV hasil "Save As" Excel (lihat README bagian Debugging)
        with open(path, "r", encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            if reader.fieldnames is None:
                logger.warning("File %s kosong.", path)
                return []
            logger.debug("Header CSV terbaca: %r", reader.fieldnames)
            header = {kolom.strip().lower() for kolom in reader.fieldnames if kolom}  # set comprehension
            kurang = sorted(set(KOLOM_WAJIB) - header)
            if kurang:
                raise FormatFileError(f"kolom wajib tidak ditemukan di {path}: {', '.join(kurang)}")
            return [
                {(kunci or "").strip().lower(): nilai for kunci, nilai in baris.items()}
                for baris in reader
            ]
    except UnicodeDecodeError:
        raise FormatFileError(f"{path} bukan file teks UTF-8") from None
    except csv.Error as e:
        raise FormatFileError(f"format CSV salah di {path}: {e}") from None


def baca_json(path):
    """Baca file JSON berisi list tugas, atau objek {"tugas": [...]}.

    Parameter: path (str). Return: list.
    Raise: FileNotFoundError, FormatFileError (JSON rusak / struktur salah).
    """
    try:
        with open(path, "r", encoding="utf-8-sig") as f:
            data = json.load(f)
    except json.JSONDecodeError as e:
        raise FormatFileError(
            f"JSON rusak di {path} (baris {e.lineno}, kolom {e.colno}): {e.msg}"
        ) from None
    except UnicodeDecodeError:
        raise FormatFileError(f"{path} bukan file teks UTF-8") from None

    if isinstance(data, dict) and "tugas" in data:
        data = data["tugas"]
    if not isinstance(data, list):
        raise FormatFileError(f"isi {path} harus berupa list tugas")
    return data


def baca_data(path):
    """Pilih pembaca sesuai ekstensi file (.csv atau .json).

    Parameter: path (str). Return: list of dict mentah.
    Raise: FileNotFoundError, FormatFileError.
    """
    ekstensi = os.path.splitext(path)[1].lower()
    if ekstensi == ".csv":
        data = baca_csv(path)
    elif ekstensi == ".json":
        data = baca_json(path)
    else:
        raise FormatFileError(
            f"ekstensi '{ekstensi or '(kosong)'}' tidak didukung, gunakan .csv atau .json"
        )
    logger.info("Membaca %d baris dari %s", len(data), path)
    return data


def _siapkan_folder(path):
    """Buat folder tujuan bila belum ada."""
    folder = os.path.dirname(path)
    if folder:
        os.makedirs(folder, exist_ok=True)


def tulis_json(path, data):
    """Simpan data ke JSON lewat file sementara agar file lama tidak rusak bila gagal.

    Parameter: path (str), data (list/dict). Return: path (str).
    Raise: OSError (mis. PermissionError).
    """
    _siapkan_folder(path)
    sementara = path + ".tmp"
    with open(sementara, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(sementara, path)
    logger.info("Menulis JSON: %s", path)
    return path


def tulis_csv(path, daftar_baris, kolom):
    """Simpan list of dict ke CSV. None ditulis sebagai sel kosong.

    Parameter: path (str), daftar_baris (list of dict), kolom (list/tuple nama kolom).
    Return: path (str). Raise: OSError.
    """
    _siapkan_folder(path)
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(kolom), extrasaction="ignore")
        writer.writeheader()
        for baris in daftar_baris:
            writer.writerow({k: ("" if baris.get(k) is None else baris.get(k)) for k in kolom})
    logger.info("Menulis CSV: %s (%d baris)", path, len(daftar_baris))
    return path
